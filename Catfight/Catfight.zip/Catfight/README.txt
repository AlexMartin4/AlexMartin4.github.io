This game is played with two XBox 360 controllers.

Controls: -Left Stick: Move left/right; Fast fall (in the air)
	  -Right Stick: Aim your throw
	  -B Button: Cancel your throw
	  -Left Trigger: Jump
	  -Right Trigger: Throw (hold to charge)
	  -Start Button: Pause the game

Menus:    -Left Stick: Select Option
	  -A button: Confirm selection

You can find a summary of these controls, as well as an arena to familiarize yourself with every weapon, in Practice Mode.

